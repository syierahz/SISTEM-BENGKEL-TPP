<?php

$dbHost = 'localhost';
$dbName = 'penggunaan'; 
$dbUsername   = 'root';
$dbPassword = '';

$mysqli = mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);
?>