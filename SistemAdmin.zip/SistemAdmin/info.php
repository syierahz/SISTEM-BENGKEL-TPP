<?php
include_once "component/connection.php";
include_once "component/header.php";
include_once "component/nav.php";
$ndp = $_GET['ndp'];
$data = mysqli_query($mysqli, "SELECT * FROM murid WHERE ndp='$ndp'");
$info = mysqli_fetch_array($data);

 ?>
 
 <center class="underline font-bold text-xl pt-6">REKOD NAMA PELAJAR KEGUNAAN BENGKEL TPP</center>
 <div class="overflow-hidden">
     <div class="flex flex-col pt-6 pr-12 pl-12">
     <div class="overflow-x-auto sm:-mx-8 lg:-mx-8">
         <div class="py-2 inline-block min-w-full sm:px-8 lg:px-8">
         
             <table class="min-w-full border text-center">
             <thead>
                 <tr class="border-b-6 bg-green-700">
                 <th scope="col" class="text-md font-medium text-white px-4 py-4 border-r">
                     Nama Penggunaan
                 </th>
                 <th scope="col" class="text-md font-medium text-white px-4 py-4 border-r">
                     Waktu Penggunaan
                 </th>
                 </tr>
                <?php
                $result = mysqli_query(
                    $mysqli,
                    "SELECT * FROM info_pengunaan WHERE ndp='$ndp'"
                );
                
                while ($r = mysqli_fetch_array($result)){
                ?>  
                <tr class="border border-black">
                    <td><?php echo $info["nama"]; ?></td>
                    <td><?php echo $r['waktu_penggunaan']; ?></td>
                </tr>
                <?php 
                }
                ?>
             </thead>
             </table>       
         </div>
     </div>
     </div>
 </div>
 <?php
 include_once "component/footer.php";
 ?>