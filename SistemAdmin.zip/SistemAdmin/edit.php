<?php 
include "component/connection.php";

if(isset($_POST['ndp'])){ 
    $ndp = $_POST['ndp'];
    $waktu_penggunaan = $_POST['waktu_penggunaan'];
     $result = mysqli_query($mysqli, "UPDATE `murid` SET `nama`='[value-1]',`ndp`='[value-2]',`password`='[value-3]',`no_tel`='[value-4]',`id_history`='[value-5]' WHERE 1'");
if($result){
    ?>
            <main x-data="app">
              <button type="button" @click="closeToast()" x-show="open" x-transition.duration.300ms class="fixed top-4 right-4 z-50 rounded-md bg-green-500 px-4 py-2 text-white transition hover:bg-green-600">
                <div class="flex items-center space-x-2">
                  <span class="text-3xl"><i class="bx bx-check"></i></span>
                  <p class="font-bold">Success!</p>
                </div>
              </button>
            </main>
                <?php
}
else{
    ?>
    <main x-data="app">
      <button type="button" @click="closeToast()" x-show="open" x-transition.duration.300ms class="fixed top-4 right-4 z-50 rounded-md bg-red-500 px-4 py-2 text-white transition hover:bg-red-600">
        <div class="flex items-center space-x-2">
          <span class="text-3xl"><i class="bx bx-x"></i></span>
          <p class="font-bold">Fail !</p>
        </div>
      </button>
    </main>
        <?php
}
    }
?>
<div class="p-8 m-8 bg-white rounded-lg">
    <button type="button" class="inline-block px-6 py-2.5 bg-red-600 text-white font-medium text-xs leading-tight uppercase rounded shadow-md hover:bg-red-700 hover:shadow-lg focus:bg-red-700 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-red-800 active:shadow-lg transition duration-150 ease-in-out"><a href="dashboard_admin.php">BACK</a></button>
</div>
<?php
$ndp = $_GET["ndp"];
$result = mysqli_query($mysqli, "SELECT * FROM masuk WHERE ndp='$ndp'");
while($res = mysqli_fetch_array($result))
{
    $ndp = $res['ndp'];
    $waktu_penggunaan = $res['waktu_penggunaan'];
}
?>
<div class="flex items-center justify-center">
    <div class="px-8 py-6 mt-20 text-left bg-white shadow-lg rounded-lg">
        <h3 class="text-2xl font-bold">UPDATE MAKLUMAT <?php echo $ndp;?></h3>
        <form method="post" enctype='multipart/form-data'>
            <div class="mt-4">
            <div class="mt-4">
                <label class="block">NDP</label>
                <input name="ndp" type="text" required class="w-full px-4 py-2 mt-2 border rounded-md focus:outline-none focus:ring-1 focus:ring-blue-600" value="<?php echo $ndp;?>">  
                </div>
                <div class="mt-4">
                <label class="block">waktu_penggunaan</label>
                <div class="mt-4">
                <input name="ndp" type="text" required class="w-full px-4 py-2 mt-2 border rounded-md focus:outline-none focus:ring-1 focus:ring-blue-600" value="<?php echo $waktu_penggunaan;?>">  
                </div>
                <div class="flex items-baseline justify-between">
                    <button type="submit" name="update" class="px-6 py-2 mt-4 text-white bg-blue-600 rounded-lg hover:bg-blue-900">Update</button>
                    <button type="reset"><a class="text-sm text-blue-600 hover:underline">Clear</a></button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php include "COMPONENT/footer.php"; ?>
